# Relay macOS icons

Two ready-to-use icon variants: **Orbit** and **Waypoints**, with the teal gradient
and warm-white symbols from the approved preview.

## Quick use

- **Xcode:** copy one variant's `AppIcon.appiconset` into `Assets.xcassets`, then
  select `AppIcon` as the target's App Icon asset. Choose one variant at a time;
  both folders intentionally use the same asset name.
- **ICNS:** each variant includes a complete `.icns` file for apps or packaging
  systems that accept a macOS icon file. It contains all 10 standard 1x/2x slots.
- **PNG:** `Relay-Orbit-1024.png` and `Relay-Waypoints-1024.png` are the individual
  1024 × 1024 RGBA masters, with transparent space outside the rounded enclosure.
- **Source:** `SVG/` includes a scalable, colored app icon, an outlined menu-bar
  symbol, and the original Lucide symbol.

## Retina sizes

| Logical size (pt) | 1x pixels | 2x pixels |
| --- | --- | --- |
| 16 × 16 | 16 × 16 | 32 × 32 |
| 32 × 32 | 32 × 32 | 64 × 64 |
| 128 × 128 | 128 × 128 | 256 × 256 |
| 256 × 256 | 256 × 256 | 512 × 512 |
| 512 × 512 | 512 × 512 | 1024 × 1024 |

Each representation is rendered independently from vector geometry and tagged
with an sRGB color profile. Small 16 pt and 32 pt variants use slightly stronger
strokes and a larger symbol for readability. Their 1x/2x versions share the same
geometry. Duplicate pixel dimensions in different logical slots are intentional.

## Native Liquid Glass

The flattened PNG, ICNS and app icon asset catalog can be used as supplied.
For a native layered icon, import `IconComposer-Layers/foreground.svg` into
Apple Icon Composer. Set a background gradient from `#497B77` to `#214E51`, or
use `background.svg` as a full-bleed background. Foreground color is `#EEF5EF`.
These layers have no baked corner mask, highlights, bevels, or shadows; the
foreground strokes are already expanded to filled shapes. Let Icon Composer
apply the system mask and material effects, then save its `.icon` file and add
that file to Xcode. The included layer files are import sources, not a finished
`.icon` document.

## Menu bar

Each variant includes a template `.imageset`: 18 × 18 px at 1x and 36 × 36 px at
2x, for an 18 pt status-item image. Import it into `Assets.xcassets`. Keep template
rendering enabled so macOS supplies the appropriate light/dark foreground color.
For AppKit, also set `NSImage.isTemplate = true` and use an 18 × 18 pt image size.

## License and sources

Glyphs: Lucide Icons and Contributors. Commercial use and modification are
permitted under the included ISC license. Retain `LICENSE-Lucide.txt` in the
distributed app's third-party notices. The palette, enclosures, outlined paths,
optical size variants, and asset packaging are adaptations of those glyphs.

- https://lucide.dev/icons/orbit
- https://lucide.dev/icons/waypoints
- https://developer.apple.com/icon-composer/
- https://developer.apple.com/design/human-interface-guidelines/app-icons
- https://developer.apple.com/library/archive/documentation/Xcode/Reference/xcode_ref-Asset_Catalog_Format/AppIconType.html

Dimensions, manifests, PNG decoding, sRGB profiles and ICNS container entries
were checked programmatically. Native Xcode compilation and Icon Composer
rendering have not been tested on a Mac.
